package com.practice.LoginAndSignup.Controllers;

import com.practice.LoginAndSignup.Models.Employee;
import com.practice.LoginAndSignup.Services.EmployeeService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/Admin")
@SecurityRequirement(name = "bearerAuth")
public class AdminController {
    @Autowired
    private EmployeeService employeeService;
    // http://localhost:8081/Admin
    @GetMapping("/getEmployee/{id}")
    public Optional<Employee> getEmployeeById(@PathVariable Long id){
        return employeeService.getEmployeeById(id);

    }
    @DeleteMapping("/deleteEmployee/{id}")
    public void deleteEmployeeById(@PathVariable Long id){
        employeeService.deleteEmployeeById(id);
    }
    @PutMapping("/updateEmployee/{id}")
    public void updateEmployee(@RequestBody Employee employee,@PathVariable Long id){
        this.employeeService.updateEmployee(employee, id);
    }
}
