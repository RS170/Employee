package com.practice.LoginAndSignup.Services;

import com.practice.LoginAndSignup.Models.Employee;
import com.practice.LoginAndSignup.Models.GetEmployeeData;
import com.practice.LoginAndSignup.repository.EmployeeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepo employeeRepo;
    public Employee addEmployee(Employee employee){
        return employeeRepo.save(employee);

    }
    public GetEmployeeData getAllEmployees(Integer pageNumber, Integer pageSize, String sortBy, String sortDir){
//        int pageSize=2;
//        int pageNumber=1;
        Sort sort=(sortDir.equalsIgnoreCase("asc"))?Sort.by(sortBy).ascending():Sort.by(sortBy).descending();
        Pageable p= PageRequest.of(pageNumber,pageSize, sort);
        Page<Employee> allEmployee = this.employeeRepo.findAll(p);
        List<Employee> allEmployeeList = allEmployee.getContent();
        GetEmployeeData getEmployeeData=new GetEmployeeData();
        getEmployeeData.setContent(allEmployeeList);
        getEmployeeData.setPageNumber(allEmployee.getNumber());
        getEmployeeData.setPageSize(allEmployee.getSize());
        getEmployeeData.setTotalElements(allEmployee.getTotalElements());
        getEmployeeData.setTotalPages(allEmployee.getTotalPages());
        getEmployeeData.setLastPage(allEmployee.isLast());
        //return allEmployeeList;
        // return (List<Employee>) employeeRepo.findAll();
        return getEmployeeData;
    }
    public Optional<Employee> getEmployeeById(Long id){
        return employeeRepo.findById(id);
    }
    public void deleteEmployeeById(Long id){
        employeeRepo.deleteById(id);
    }
    public void updateEmployee(Employee employee, Long id){
//        Optional<Employee> employeeById = this.getEmployeeById(id);
        Optional<Employee> employeeById = employeeRepo.findById(id);
        Employee employeeToUpdate = employeeById.get();
        employeeToUpdate.setEmail(employee.getEmail());
        employeeToUpdate.setName(employee.getName());
        employeeRepo.save(employeeToUpdate);

    }
    public List<Employee> searchEmployees(Long id,String keyword){
        if(id!=null){
            return employeeRepo.findById(id).stream().collect(Collectors.toList());
        } else if (keyword!=null && !keyword.trim().isEmpty()) {
            return employeeRepo.searchEmployee(keyword);
        }else {
            return employeeRepo.findAll();
        }

    }

}
