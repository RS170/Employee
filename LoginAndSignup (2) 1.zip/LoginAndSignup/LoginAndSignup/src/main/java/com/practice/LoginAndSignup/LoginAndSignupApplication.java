package com.practice.LoginAndSignup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginAndSignupApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginAndSignupApplication.class, args);
	}

}
