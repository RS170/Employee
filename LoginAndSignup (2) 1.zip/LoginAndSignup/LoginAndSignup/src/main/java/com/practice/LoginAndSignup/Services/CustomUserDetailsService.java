package com.practice.LoginAndSignup.Services;

import com.practice.LoginAndSignup.Models.RegisteredUsers;
import com.practice.LoginAndSignup.repository.RegisteredUsersRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService implements UserDetailsService {
    @Autowired
    private final RegisteredUsersRepo registeredUsersRepo;

    public CustomUserDetailsService(RegisteredUsersRepo registeredUsersRepo) {
        this.registeredUsersRepo = registeredUsersRepo;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        RegisteredUsers registeredUsers=registeredUsersRepo.findByUsername(username);
        if(registeredUsers==null){
            throw  new UsernameNotFoundException("User not found");
        }
        return User.builder()
                .username(registeredUsers.getUsername())
                .password(registeredUsers.getPassword())
                .roles(registeredUsers.getRole())
                .build();
    }
}
