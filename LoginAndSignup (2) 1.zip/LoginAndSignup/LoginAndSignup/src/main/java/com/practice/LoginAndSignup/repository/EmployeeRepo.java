package com.practice.LoginAndSignup.repository;

import com.practice.LoginAndSignup.Models.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepo extends JpaRepository<Employee,Long> {
    @Query("SELECT e FROM Employee e WHERE "+
            "LOWER(e.name) LIKE LOWER(CONCAT('%',:keyword,'%')) OR "+
            "LOWER(e.email) LIKE LOWER(CONCAT('%',:keyword,'%'))")
    List<Employee> searchEmployee( String keyword);
}
