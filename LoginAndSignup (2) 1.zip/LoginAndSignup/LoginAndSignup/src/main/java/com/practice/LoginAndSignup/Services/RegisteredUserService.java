package com.practice.LoginAndSignup.Services;

import com.practice.LoginAndSignup.Models.RegisteredUsers;
import com.practice.LoginAndSignup.repository.RegisteredUsersRepo;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class RegisteredUserService {
    private final RegisteredUsersRepo registeredUsersRepo;
    private final PasswordEncoder passwordEncoder;

    public RegisteredUserService(RegisteredUsersRepo registeredUsersRepo, PasswordEncoder passwordEncoder) {
        this.registeredUsersRepo = registeredUsersRepo;

        this.passwordEncoder = passwordEncoder;
    }
    public RegisteredUsers saveUser(RegisteredUsers registeredUsers){
        registeredUsers.setPassword(passwordEncoder.encode(registeredUsers.getPassword()));
        return registeredUsersRepo.save(registeredUsers);
    }
    public RegisteredUsers findByUsername(String username){
        return registeredUsersRepo.findByUsername(username);
    }
}
