package com.practice.LoginAndSignup.Controllers;

import com.practice.LoginAndSignup.Models.Employee;
import com.practice.LoginAndSignup.Models.GetEmployeeData;
import com.practice.LoginAndSignup.Services.EmployeeService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;
import java.util.Optional;

//RestController will return the data in Json format.
@RestController
@RequestMapping("/User")
@SecurityRequirement(name = "bearerAuth")
public class UserController {
    @Autowired
    private EmployeeService employeeService;
    // http://localhost:8081/User

    @PostMapping("/addEmployee")
    public Employee addEmployee(@RequestBody Employee employee){
        return employeeService.addEmployee(employee);
    }
    @GetMapping("/getAllEmployees")
    public GetEmployeeData getAllEmployees(@RequestParam(value = "pageNumber",defaultValue = "0",required = false)Integer pageNumber,
                                           @RequestParam(value = "pageSize",defaultValue = "5",required = false)Integer pageSize,
                                           @RequestParam(value = "sortBy",defaultValue = "Id",required = false)String sortBy,
                                           @RequestParam(value = "sortDir",defaultValue = "asc",required = false)String sortDir){
        return employeeService.getAllEmployees(pageNumber,pageSize,sortBy,sortDir);
    }
    @GetMapping("/current-user")
    public String getLoggedInUser(Principal principal){
        return principal.getName();
    }
    @GetMapping("/getEmployees/search")
    public List<Employee>searchEmployees(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Long id
    ){
        return employeeService.searchEmployees(id,keyword);
    }
}
