package com.practice.LoginAndSignup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginAndSignupApplicationTests {

	@Test
	void contextLoads() {
	}

}
